
public class Moto extends Vehiculo {
	private int cilindros;

	public Moto(String placa, String marca, String modelo, double costo_por_dia, int cilindros) {
		super(placa, marca, modelo, costo_por_dia);
		this.cilindros = cilindros;
	}

	public int getCilindros() {
		return cilindros;
	}

	public void setCilindros(int cilindros) {
		this.cilindros = cilindros;
	}

	public double calcularCostoRenta(int dias, Cliente cliente) {
		return 0;
	}

	public String toString() {
		return "Coche: [Marca: " + marca + ", Modelo: " + modelo + ", Número de cilíndros: " + cilindros + ", Placa: "
				+ placa + ", Costo por dia: " + costo_por_dia + "]";
	}
}
