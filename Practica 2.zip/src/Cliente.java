
public abstract class Cliente {

}
