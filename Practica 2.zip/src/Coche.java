
public class Coche extends Vehiculo {
	private String transmision;
	private int puertas;

	public Coche(String placa, String marca, String modelo, double costo_por_dia, String transmisión, int puertas) {
		super(placa, marca, modelo, costo_por_dia);
		this.transmision = transmisión;
		this.puertas = puertas;
	}

	public String getTransmisión() {
		return transmision;
	}

	public int getPuertas() {
		return puertas;
	}

	public double calcularCostoRenta(int dias, Cliente cliente) {
		return 0;
	}

	public String toString() {
		return "Coche: [Marca: " + marca + ", Modelo: " + modelo + ", Transmisión: " + transmision + 
				", Número de puertas: " + puertas + ", Placa: " + placa + ", Costo por dia: " + costo_por_dia + "]";
	}	
	
}
