
public class Camioneta extends Vehiculo {
	private String transmision;
	private int pasajeros;

	public Camioneta(String placa, String marca, String modelo, double costo_por_dia, String transmision,
			int pasajeros) {
		super(placa, marca, modelo, costo_por_dia);
		this.transmision = transmision;
		this.pasajeros = pasajeros;
	}

	public String getTransmisión() {
		return transmision;
	}

	public void setTransmisión(String transmisión) {
		this.transmision = transmisión;
	}

	public int getPasajeros() {
		return pasajeros;
	}

	public void setPasajeros(int pasajeros) {
		this.pasajeros = pasajeros;
	}

	public double calcularCostoRenta(int dias, Cliente cliente) {
		return 0;
	}

	public String toString() {
		return "Coche: [Marca: " + marca + ", Modelo: " + modelo + ", Transmisión: " + transmision
				+ ", Número de pasajeros: " + pasajeros + ", Placa: " + placa + ", Costo por dia: " + costo_por_dia
				+ "]";
	}
}
