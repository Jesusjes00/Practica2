
public class Agencia {
	private String nombre;
	private Vehiculo[] vehiculo = new Vehiculo[8];

	public Agencia() {
		this.nombre = "AutoMove";
		vehiculo[0] = new Coche("ABF-472", "Chevrolet", "Aveo", 1199.99, "Manual", 4);
		vehiculo[1] = new Coche("KLM-905", "Volkswagen", "Golf", 1399.99, "Automático", 4);
		vehiculo[2] = new Coche("TRX-318", "Mercedes", "Maybach", 7999.99, "Manual", 4);
		vehiculo[3] = new Camioneta("YHG-662", "Nissan", "Kicks", 1599.99, "Manual", 5);
		vehiculo[4] = new Camioneta("PQR-741", "Honda", "CR-V", 1799.99, "Automático", 7);
		vehiculo[5] = new Camioneta("VBN-289", "Toyota", "Tacoma", 2499.99, "Manual", 5);
		vehiculo[6] = new Moto("84J-K2", "Italika", "250Z", 699.99, 1);
		vehiculo[7] = new Moto("19M-R7", "Kawazaki", "Ninja ZX-10R", 2999.99, 4);

	}

}
